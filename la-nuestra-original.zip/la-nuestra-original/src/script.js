// Clase principal para la aplicación de Radio LA NUESTRA
class RadioApp {
    constructor() {
        this.currentPage = 'page-inicio';
        this.chart = null;
        this.chartInitialized = false;
        this.isPlaying = false;
        this.init();
    }
    
    init() {
        this.setupNavigation();
        this.setupFlipCards();
        this.setupKeyboardNavigation();
        this.setupLiveButton();
        this.showPage('page-inicio');
        this.checkImageStatus();
    }
    
    setupNavigation() {
        document.getElementById('navigation').addEventListener('click', (e) => {
            if (e.target.classList.contains('nav-link')) {
                const pageId = e.target.getAttribute('data-page');
                this.showPage(pageId);
            }
        });
    }
    
    setupFlipCards() {
        document.addEventListener('click', (e) => {
            const flipCard = e.target.closest('.flip-card');
            if (flipCard) {
                flipCard.classList.toggle('flipped');
                const isFlipped = flipCard.classList.contains('flipped');
                flipCard.setAttribute('aria-pressed', isFlipped);
            }
        });
        
        document.addEventListener('keydown', (e) => {
            if (e.key === 'Enter' || e.key === ' ') {
                const flipCard = document.activeElement.closest('.flip-card');
                if (flipCard && document.activeElement === flipCard) {
                    e.preventDefault();
                    flipCard.classList.toggle('flipped');
                    const isFlipped = flipCard.classList.contains('flipped');
                    flipCard.setAttribute('aria-pressed', isFlipped);
                }
            }
        });
    }
    
    setupLiveButton() {
        const liveButton = document.getElementById('liveButton');
        const liveButtonHero = document.querySelector('.live-button-hero');
        const closeButton = document.querySelector('.close-button');
        const modal = document.getElementById('liveModal');
        
        // Función para abrir el modal
        const openModal = () => {
            modal.classList.remove('hidden');
            document.body.style.overflow = 'hidden';
        }
        
        // Función para cerrar el modal
        const closeModal = () => {
            modal.classList.add('hidden');
            document.body.style.overflow = 'auto';
            const audio = document.getElementById('radioStream');
            if (audio) {
                audio.pause();
                this.isPlaying = false;
            }
        }
        
        // Event listeners
        if (liveButton) liveButton.addEventListener('click', openModal);
        if (liveButtonHero) liveButtonHero.addEventListener('click', openModal);
        if (closeButton) closeButton.addEventListener('click', closeModal);
        
        // Cerrar modal al hacer clic fuera
        if (modal) {
            modal.addEventListener('click', (e) => {
                if (e.target === modal) {
                    closeModal();
                }
            });
        }
        
        // Cerrar con tecla Escape
        document.addEventListener('keydown', (e) => {
            if (e.key === 'Escape' && modal && !modal.classList.contains('hidden')) {
                closeModal();
            }
        });
    }
    
    setupKeyboardNavigation() {
        document.addEventListener('keydown', (e) => {
            if (e.key === 'ArrowRight' || e.key === 'ArrowLeft') {
                const navLinks = Array.from(document.querySelectorAll('.nav-link'));
                const currentIndex = navLinks.findIndex(link => link.classList.contains('active'));
                
                if (currentIndex !== -1) {
                    let newIndex;
                    if (e.key === 'ArrowRight') {
                        newIndex = (currentIndex + 1) % navLinks.length;
                    } else {
                        newIndex = (currentIndex - 1 + navLinks.length) % navLinks.length;
                    }
                    
                    const pageId = navLinks[newIndex].getAttribute('data-page');
                    this.showPage(pageId);
                    navLinks[newIndex].focus();
                }
            }
        });
    }
    
    showPage(pageId) {
        document.querySelectorAll('.content-section').forEach(section => {
            section.classList.add('hidden');
        });
        
        const targetSection = document.getElementById(pageId);
        if (targetSection) {
            targetSection.classList.remove('hidden');
        }
        
        document.querySelectorAll('.nav-link').forEach(link => {
            link.classList.remove('active');
            link.removeAttribute('aria-current');
            
            if (link.getAttribute('data-page') === pageId) {
                link.classList.add('active');
                link.setAttribute('aria-current', 'page');
            }
        });
        
        if (pageId === 'page-inicio') {
            this.initChart();
        }
        
        this.currentPage = pageId;
        window.scrollTo({ top: 0, behavior: 'smooth' });
    }
    
    initChart() {
        if (this.chartInitialized && this.chart) return;
        
        const ctx = document.getElementById('programFocusChart');
        if (!ctx) return;
        
        const canvasCtx = ctx.getContext('2d');
        
        if (this.chart instanceof Chart) {
            this.chart.destroy();
        }
        
        const colorAzulOscuro = '#172A5C';
        const colorRojo = '#FF0000';
        const colorAmarillo = '#FACC15';
        const colorAzulClaro = '#3b82f6';
        
        this.chart = new Chart(canvasCtx, {
            type: 'doughnut',
            data: {
                labels: [
                    'Salsa (Salsa y Sabor)',
                    'Talento Local/Actual (Show, Las 20)',
                    'Vallenato (La Onda Vallenata)',
                    'Clásicos (Feeling del Recuerdo)',
                    'Magazín/Nuevos Artistas (Mañanas)'
                ],
                datasets: [{
                    label: 'Foco de Programación',
                    data: [25, 25, 20, 20, 10],
                    backgroundColor: [
                        colorRojo,
                        colorAzulClaro,
                        colorAmarillo,
                        colorAzulOscuro,
                        'rgba(107, 114, 128, 0.8)'
                    ],
                    borderColor: [
                        '#ffffff',
                        '#ffffff',
                        '#ffffff',
                        '#ffffff',
                        '#ffffff'
                    ],
                    borderWidth: 2
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        position: 'bottom',
                        labels: {
                            boxWidth: 12,
                            padding: 15,
                            font: {
                                size: 11
                            }
                        }
                    },
                    tooltip: {
                        callbacks: {
                            label: function(context) {
                                return `${context.label}: ${context.parsed}%`;
                            }
                        }
                    }
                }
            }
        });
        
        this.chartInitialized = true;
    }
    
    checkImageStatus() {
        // Verificar estado de las imágenes después de cargar
        setTimeout(() => {
            const images = document.querySelectorAll('img');
            console.log('=== VERIFICACIÓN DE IMÁGENES ===');
            images.forEach((img, index) => {
                if (img.complete && img.naturalHeight !== 0) {
                    console.log(`✅ Imagen ${index + 1} cargada: ${img.src}`);
                } else {
                    console.log(`❌ Imagen ${index + 1} NO cargada: ${img.src}`);
                    // Crear placeholder si la imagen no carga
                    this.createPlaceholder(img);
                }
            });
        }, 2000);
    }
    
    createPlaceholder(imgElement) {
        const placeholder = document.createElement('div');
        placeholder.className = 'image-placeholder';
        placeholder.innerHTML = `
            <div class="placeholder-icon">📷</div>
            <div>Imagen no disponible</div>
            <div class="text-xs mt-2">${imgElement.alt}</div>
        `;
        
        imgElement.parentNode.insertBefore(placeholder, imgElement);
        imgElement.style.display = 'none';
    }
}

// Inicializar aplicación cuando el DOM esté listo
document.addEventListener('DOMContentLoaded', () => {
    new RadioApp();
});